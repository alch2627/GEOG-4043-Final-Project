var map;
var minValue;
var dataStats = {};
var colors = [];
var attrArray = ["Any", "Iron", "Chondrite", "Achondrite", "Stony-Iron", "Stony", "Unclassified"];
var expressed;
var mappy;

function createMap(){

    //create the map
    map = L.map('mapId', {
        center: [0, 0],
        zoom: 4,
        maxBoundsViscosity: 1.0
    });
    map.setMaxBounds([[-90,-180],[90,180]]);
    //add OSM base tilelayer
    L.tileLayer('https://api.mapbox.com/styles/v1/alch2627/ckvspn2by193d15qstl0e9tml/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYWxjaDI2MjciLCJhIjoiY2t0YW4zMTlmMW5zMTJvcW55bTRuMjVkcyJ9.GsqehXFywlQEsXmvbwlZvg', {
        minZoom: 3,
        noWrap: true,
        attribution: 'Map data: &copy; <a href=”https://www.mapbox.com/about/maps/”>Mapbox</a> &copy; <a href=”http://www.openstreetmap.org/copyright”>OpenStreetMap</a>)'
    }).addTo(map);

    //call getData function
    getData(map);
};


function calcStats(data){
    //create empty array to store all data values
    var allValues = [];
    var min = 100000000;
    var max = 0;
    var sum = 0;
    //loop through each meteor
    for(var Name of data.features){
        var value = parseFloat(Name.properties["Mass (g)"]);
        if (value > 0)
        {
            sum += value;
        }
        if (value < min && value > 0)
        {
            min = value;
        }
        if (value > max)
        {
            max = value;
        }
        //add value to array
        allValues.push(value);
        //console.log(sum);
    }
    //console.log(min);
    //console.log(max);
    //console.log(sum);

    var avg = sum/allValues.length;
    dataStats.min = min;
    dataStats.max = Math.round(max);
    dataStats.mean = Math.round(avg);
}

function calculateMinValue(data){
    //create empty array to store all data values
    var allValues = [];
    //loop through each city
    for(var Name of data.features){
        var value = parseFloat(Name.properties["Mass (g)"]);
        //add value to array
        allValues.push(value);
    }
    //get minimum value of our array
    var minValue = Math.min(...allValues)
    return minValue;
}

//15 max, 10, 8, 6
function calcPropRadius(attValue) {
    //constant factor adjusts symbol sizes evenly
    var minRadius = 4;
    var radius;
    //Flannery Apperance Compensation formula
    if (attValue <= 2000)
    {
        radius = 4;
    }
    if (attValue > 2000 && attValue <= 50000)
    {
        radius = 8;
    }
    if (attValue > 50000  && attValue <= 2000000)
    {
        radius = 15;
    }
    if (attValue > 2000000 && attValue <= 4000000)
    {
        radius = 22;
    }
    if (attValue > 4000000)
    {
        radius = 30;
    }

    return radius;
};

function setColor(data){
    var allValues = [];
    var colorValues = [];
    for(var Name of data.features){
        var value = Name.properties["Composition"]
        allValues.push(value)
    }
    counter = 0
    /*for (var i = 0; i < allValues.length; i++){
        if (allValues[i] == 'Chondrite'){
            colorValues[i] = "Red"
        }
        else if (allValues[i] == "Achondrite"){
            colorValues[i] = "Orange"
        }
        else if (allValues[i] == "Stony"){
            colorValues[i] = "Yellow"
        }
        else if (allValues[i] == "Iron"){
            colorValues[i] = "Blue"
        }
        else if (allValues[i] == "Stony-Iron"){
            colorValues[i] = "Green"
        }
        else {
            colorValues[i] = "Gray"
        }
    }*/
    return allValues;
}

function createPropSymbols(data){

    var attribute = "Mass (g)";
    //create marker options
    var geojsonMarkerOptions = {
        color: "white",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8,
        radius: 8
    };

    mappy = L.geoJson(data, {
        filter: filterData,
        pointToLayer: function (feature, latlng) {
            //Step 5: For each feature, determine its value for the selected attribute
            var attValue = parseFloat(feature.properties[attribute]);

            //Step 6: Give each feature's circle marker a radius based on its attribute value
            geojsonMarkerOptions.radius = calcPropRadius(attValue);
            //console.log(attValue)

            //geojsonMarkerOptions.color = setColor(attValue)
            if (feature.properties.Composition =="Chondrite")
            {
                geojsonMarkerOptions.fillColor = "#F50076";
            } else if  (feature.properties.Composition =="Iron")
            {
                geojsonMarkerOptions.fillColor = "#00A5F5";
            } else if  (feature.properties.Composition =="Achondrite")
            {
                geojsonMarkerOptions.fillColor = "#FFE800";
            } else if (feature.properties.Composition == "Stony")
            {
                geojsonMarkerOptions.fillColor = "#FF7700";
            } else if (feature.properties.Composition == "Stony-Iron")
            {
                geojsonMarkerOptions.fillColor = "#00FF9C";
            } else {
                geojsonMarkerOptions.fillColor = "Gray";
            }
            //create circle markers
            layer = L.circleMarker(latlng, geojsonMarkerOptions);

            var popupContent = "<p><b>Meteor:</b> " + feature.properties.Name + "</p>";

            //add formatted attribute to popup content string
            popupContent += "<p><b>Mass: </b> " + " " + feature.properties["Mass (g)"] + " grams</p>";

            popupContent += "<p><b>Composition: </b> " + " " + feature.properties.Composition + "</p>";

            popupContent += "<p><b>Date: </b> " + " " + feature.properties.Date + "</p>";

            //bind the popup to the circle marker
            layer.bindPopup(popupContent, {
                //offset: new L.Point(0,-options.radius)
            })
            return layer;

        }
    }).addTo(map);
};

function filterData(data)
{
    if (expressed == "Any" || expressed == "Select Classification")
    {
        return true;
    }
    else if (data.properties.Composition == "Iron" && expressed == "Iron")
    {
        return true;
    }
    else if (data.properties.Composition == "Chondrite" && expressed == "Chondrite")
    {
        return true;
    }
    else if (data.properties.Composition == "Achondrite" && expressed == "Achondrite")
    {
        return true;
    }
    else if (data.properties.Composition == "Stony-Iron" && expressed == "Stony-Iron")
    {
        return true;
    }
    else if (data.properties.Composition == "Stony" && expressed == "Stony")
    {
        return true;
    }
    else if (data.properties.Composition == "Unclassified" && expressed == "Unclassified")
    {
        return true;
    }
    else{
        return false;
    }   
};

function createDropdown(data) {
    //add select element
    expressed = "Select Classification";
    var dropdown = d3
        .select("body")
        .append("select")
        .style("z-index", "999")
        .attr("class", "dropdown")
        .on("change", function () {
            changeAttribute(this.value, data);
        });
    //add initial option
    var titleOption = dropdown
        .append("option")
        .attr("class", "titleOption")
        .attr("disabled", "true")
        .text("Select Classification");

    //add attribute name options
    var attrOptions = dropdown
        .selectAll("attrOptions")
        .data(attrArray)
        .enter()
        .append("option")
        .attr("value", function (d) {
            return d;
        })
        .text(function (d) {
            return d;
        });
}

//dropdown change listener handler
function changeAttribute(attribute, data) {
    //change the expressed attribute
    expressed = attribute;
    console.log(expressed);
    var geojsonMarkerOptions = {
        color: "white",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8,
        radius: 8
    };
    mappy.clearLayers();
    createPropSymbols(data);
};


function createLegend(data){
    var LegendControl = L.Control.extend({
        options: {
            position: 'bottomright'
        },

        onAdd: function () {
            // create the control container with a particular class name
            var container = L.DomUtil.create('div', 'legend-control-container');

            $(container).append('<div class="temporalLegend">Mass of Meteorite</div>');

            //Step 1: start attribute legend svg string
            var svg = '<svg id="attribute-legend" width="130px" height="130px">';

            //array of circle names to base loop on
            var circles = ["max", "mean", "min"];
            //console.log(dataStats);

            //Step 2: loop to add each circle and text to svg string  
            for (var i=0; i<circles.length; i++){  
  
                //Step 3: assign the r and cy attributes            
                var radius = calcPropRadius(dataStats[circles[i]]);
                //console.log(circles[i] + " Radius " + radius);           
                var cy = 59 - radius;
                //console.log(cy);            
            
                //circle string            
                svg += '<circle class="legend-circle" id="' + circles[i] + '" r="' + radius + '"cy="' + cy + '" fill="#F47821" fill-opacity="0.8" stroke="#000000" cx="30"/>';
            
                //evenly space out labels            
                var textY = i * 20 + 20;            
            
                //text string            
                svg += '<text id="' + circles[i] + '-text" x="75" y="' + textY + '">' + dataStats[circles[i]].toPrecision(1) + " g" + '</text>'; 
            };  

            //close svg string
            svg += "</svg>";

            //add attribute legend svg to container
            $(container).append(svg);

            return container;
        }
    });

    map.addControl(new LegendControl());
};

function createCredits(){
    var credits = L.Control.extend({
        options: {
            position: 'bottomleft'
        },

        onAdd: function () {
            // create the control container with a particular class name
            var creditcontents = L.DomUtil.create('div', 'credits-contents');

            $(creditcontents).append('<div class="creditsbox">Credits</div>');

            //Step 1: start attribute legend svg string
            var svg2 = '<svg id="credits-box" width="600px" height="150px">';

            svg2 += '<text id="' + "5" + '-text" x="2" y="' + 20 + '">' + "This map was created by Alex Chang" + '</text>'
            svg2 += '<text id="' + "6" + '-text" x="2" y="' + 35 + '">' + "Asher Eskind, Adam Straussburger," + '</text>'
            svg2 += '<text id="' + "7" + '-text" x="2" y="' + 50 + '">' + "and Marcus Tamburro. All data came" + '</text>'
            svg2 += '<text id="' + "7" + '-text" x="2" y="' + 65 + '">' + "from the following link: " + '</text>'
            svg2 += '<text id="' + "7" + '-text" x="2" y="' + 80 + '">' + "insert github link here " + '</text>'
            svg2 += '<text id="' + "7" + '-text" x="2" y="' + 95 + '">' + "The data displays meteorites which" + '</text>'
            svg2 += '<text id="' + "7" + '-text" x="2" y="' + 110 + '">' + "were seen falling and found after" + '</text>'
            svg2 += '<text id="' + "85" + '-text" x="2" y="' + 125 + '">' + "making impact with the ground." + '</text>'


            //close svg string
            svg2 += "</svg>";

            //add attribute legend svg to container
            $(creditcontents).append(svg2);

            return creditcontents;
        }
    });

    map.addControl(new credits());
};





function getData(map){
    //load the data
    $.getJSON("data/meteorites.geojson", function(response){

            createDropdown(response);
            //calculate minimum data value
            minValue = calculateMinValue(response);
            //call function to create proportional symbols
            colors = setColor(response);
            createPropSymbols(response);
            calcStats(response); 
            createLegend(response);
            createCredits();
    });
};

$(document).ready(createMap);