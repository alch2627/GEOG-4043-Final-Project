var map;
var minValue;

function createMap(){

    //create the map
    map = L.map('mapId', {
        center: [0, 0],
        zoom: 4,
        maxBoundsViscosity: 1.0
    });
    map.setMaxBounds([[-90,-180],[90,180]]);
    //add OSM base tilelayer
    L.tileLayer('https://api.mapbox.com/styles/v1/alch2627/ckvspn2by193d15qstl0e9tml/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYWxjaDI2MjciLCJhIjoiY2t0YW4zMTlmMW5zMTJvcW55bTRuMjVkcyJ9.GsqehXFywlQEsXmvbwlZvg', {
        minZoom: 2,
        attribution: 'Map data: &copy; <a href=”https://www.mapbox.com/about/maps/”>Mapbox</a> &copy; <a href=”http://www.openstreetmap.org/copyright”>OpenStreetMap</a>)'
    }).addTo(map);

    //call getData function
    getData(map);
};

function calculateMinValue(data){
    //create empty array to store all data values
    var allValues = [];
    //loop through each city
    for(var Name of data.features){
        var value = parseFloat(Name.properties["Mass (g)"]);
        //add value to array
        allValues.push(value);
    }
    //get minimum value of our array
    var minValue = Math.min(...allValues)
    return minValue;
}

function calcPropRadius(attValue) {
    //constant factor adjusts symbol sizes evenly
    var minRadius = 2;
    //Flannery Apperance Compensation formula
    var radius = Math.log10(attValue)

    return radius;
};

function setColor(data){
    var allValues = [];
    for(var name of data.feature){
        var value = name.properties["Composition"]
        allValues.push(value)
    }
    console.log(allValues)
}

function createPropSymbols(data){

    var attribute = "Mass (g)";
    //create marker options
    var geojsonMarkerOptions = {
        fillColor: "#ff7800",
        color: "#fff",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8,
        radius: 8
    };

    L.geoJson(data, {
        pointToLayer: function (feature, latlng) {
            //Step 5: For each feature, determine its value for the selected attribute
            var attValue = parseFloat(feature.properties[attribute]);

            //Step 6: Give each feature's circle marker a radius based on its attribute value
            geojsonMarkerOptions.radius = calcPropRadius(attValue);
            console.log(attValue)

            //create circle markers
            return L.circleMarker(latlng, geojsonMarkerOptions);
        }
    }).addTo(map);
};



function getData(map){
    //load the data
    $.getJSON("data/meteorites.geojson", function(response){

            //calculate minimum data value
            minValue = calculateMinValue(response);
            //call function to create proportional symbols
            createPropSymbols(response);
    });
};

$(document).ready(createMap);
/*$.getJSON("data/meteorites.geojson", function(response){
    var geojsonMarkerOptions = {
        radius: 2,
        fillColor: "#ff7800",
        color: "#000",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    };
    //create a Leaflet GeoJSON layer and add it to the map
    L.geoJson(response, {
        pointToLayer: function (feature, latlng){
            return L.circleMarker(latlng, geojsonMarkerOptions);
        }
    }).addTo(map);
});*/