var map;
var minValue;
var dataStats = {};

function createMap(){

    //create the map
    map = L.map('mapId', {
        center: [0, 0],
        zoom: 4,
        maxBoundsViscosity: 1.0
    });
    map.setMaxBounds([[-90,-180],[90,180]]);
    //add OSM base tilelayer
    L.tileLayer('https://api.mapbox.com/styles/v1/alch2627/ckvspn2by193d15qstl0e9tml/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYWxjaDI2MjciLCJhIjoiY2t0YW4zMTlmMW5zMTJvcW55bTRuMjVkcyJ9.GsqehXFywlQEsXmvbwlZvg', {
        minZoom: 2,
        attribution: 'Map data: &copy; <a href=”https://www.mapbox.com/about/maps/”>Mapbox</a> &copy; <a href=”http://www.openstreetmap.org/copyright”>OpenStreetMap</a>)'
    }).addTo(map);

    //call getData function
    getData(map);
};


function calcStats(data){
    //create empty array to store all data values
    var allValues = [];
    var min = 100000000;
    var max = 0;
    var sum = 0;
    //loop through each meteor
    for(var Name of data.features){
        var value = parseFloat(Name.properties["Mass (g)"]);
        if (value > 0)
        {
            sum += value;
        }
        if (value < min && value > 0)
        {
            min = value;
        }
        if (value > max)
        {
            max = value;
        }
        //add value to array
        allValues.push(value);
        //console.log(sum);
    }
    console.log(min);
    console.log(max);
    console.log(sum);

    var avg = sum/allValues.length;
    dataStats.min = min;
    dataStats.max = max;
    dataStats.mean = avg;
}

function calculateMinValue(data){
    //create empty array to store all data values
    var allValues = [];
    //loop through each city
    for(var Name of data.features){
        var value = parseFloat(Name.properties["Mass (g)"]);
        //add value to array
        allValues.push(value);
    }
    //get minimum value of our array
    var minValue = Math.min(...allValues)
    return minValue;
}

function calcPropRadius(attValue) {
    //constant factor adjusts symbol sizes evenly
    var minRadius = 2;
    //Flannery Apperance Compensation formula
    var radius = Math.log10(attValue)

    return radius;
};

function setColor(data){
    var allValues = [];
    for(var name of data.feature){
        var value = name.properties["Composition"]
        allValues.push(value)
    }
    //console.log(allValues)
}

function createPropSymbols(data){

    var attribute = "Mass (g)";
    //create marker options
    var geojsonMarkerOptions = {
        fillColor: "#ff7800",
        color: "#fff",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8,
        radius: 8
    };

    L.geoJson(data, {
        pointToLayer: function (feature, latlng) {
            //Step 5: For each feature, determine its value for the selected attribute
            var attValue = parseFloat(feature.properties[attribute]);

            //Step 6: Give each feature's circle marker a radius based on its attribute value
            geojsonMarkerOptions.radius = calcPropRadius(attValue);
            //console.log(attValue)

            //create circle markers
            return L.circleMarker(latlng, geojsonMarkerOptions);
        }
    }).addTo(map);
};



function getData(map){
    //load the data
    $.getJSON("data/meteorites.geojson", function(response){

            //calculate minimum data value
            minValue = calculateMinValue(response);
            //call function to create proportional symbols
            createPropSymbols(response);
            createFilter(response);
            calcStats(response); 
            createLegend(response);
    });
};

function createFilter(data){
    var LegendControl = L.Control.extend({
        options: {
            position: 'topright'
        },

        onAdd: function () {
            // create the control container with a particular class name
            var container = L.DomUtil.create('div', 'dropdown');
            //Creating dropdown menu with the 6 different compositions of meteorites
            $(container).append('<div class="dropdownmenu">Filter By Composition <select>id="comp-select"<option value="Any">Any</option><option value="Iron">Iron</option><option value="Chondrite">Chondrite</option><option value="Achondrite">Achondrite</option><option value="Stony-Iron">Stony-Iron</option><option value="Stony">Stony</option><option value="Unclassified">Unclassified</option></select> </div>');
            //Step 1: start attribute legend svg string
            var svg = '<svg id="dropdown-menu" width="300px" height="10px">';


            //add attribute legend svg to container
            $(container).append(svg);
            return container;
        }
    });
    map.addControl(new LegendControl());
};

function createLegend(data){
    var LegendControl = L.Control.extend({
        options: {
            position: 'bottomright'
        },

        onAdd: function () {
            // create the control container with a particular class name
            var container = L.DomUtil.create('div', 'legend-control-container');

            $(container).append('<div class="temporalLegend">Population in <span class="year">1980</span></div>');

            //Step 1: start attribute legend svg string
            var svg = '<svg id="attribute-legend" width="130px" height="130px">';

            //array of circle names to base loop on
            var circles = ["max", "mean", "min"];
            console.log(dataStats);

            //Step 2: loop to add each circle and text to svg string  
            for (var i=0; i<circles.length; i++){  
  
                //Step 3: assign the r and cy attributes            
                var radius = calcPropRadius(dataStats[circles[i]]);           
                var cy = 59 - radius;            
            
                //circle string            
                svg += '<circle class="legend-circle" id="' + circles[i] + '" r="' + radius + '"cy="' + cy + '" fill="#F47821" fill-opacity="0.8" stroke="#000000" cx="30"/>';
            
                //evenly space out labels            
                var textY = i * 20 + 20;            
            
                //text string            
                svg += '<text id="' + circles[i] + '-text" x="65" y="' + textY + '">' + Math.round(dataStats[circles[i]]*100)/100 + " million" + '</text>'; 
            };  

            //close svg string
            svg += "</svg>";

            //add attribute legend svg to container
            $(container).append(svg);

            return container;
        }
    });

    map.addControl(new LegendControl());
};


$(document).ready(createMap);
/*$.getJSON("data/meteorites.geojson", function(response){
    var geojsonMarkerOptions = {
        radius: 2,
        fillColor: "#ff7800",
        color: "#000",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    };
    //create a Leaflet GeoJSON layer and add it to the map
    L.geoJson(response, {
        pointToLayer: function (feature, latlng){
            return L.circleMarker(latlng, geojsonMarkerOptions);
        }
    }).addTo(map);
});*/